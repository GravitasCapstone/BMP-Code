/*******************************************************************************
  MPLAB Harmony Project Main Source File

  Company:
    Microchip Technology Inc.
  
  File Name:
    main.c

  Summary:
    This file contains the "main" function for an MPLAB Harmony project.

  Description:
    This file contains the "main" function for an MPLAB Harmony project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state 
    machines of all MPLAB Harmony modules in the system and it calls the 
    "SYS_Tasks" function from within a system-wide "super" loop to maintain 
    their correct operation. These two functions are implemented in 
    configuration-specific files (usually "system_init.c" and "system_tasks.c")
    in a configuration-specific folder under the "src/system_config" folder 
    within this project's top-level folder.  An MPLAB Harmony project may have
    more than one configuration, each contained within it's own folder under
    the "system_config" folder.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

//Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "system/common/sys_module.h"   // SYS function prototypes
#include "bmp3_defs.h"
#include "bmp3.h"
#include "bmp3.c"
#include "bsp.h"
#include "driver/usart/drv_usart.h"

#define HDC_ADDRESS 0x40            // The address of HDC2080 when the ADDR pin is connected to ground
#define TEMP_LOW 0x00
#define TEMP_HIGH 0x01
#define HUMID_LOW 0x02
#define HUMID_HIGH 0x03 
#define HDC_Meas_Config_Reg 0x0F
#define HDC_Config_Reg 0x0E

struct bmp3_dev dev;

struct bmp3_data data;

#define SYS_FREQ 200000000

void delay_us(unsigned int us);

void delay_ms(unsigned int ms);

// Waits for the bus to be empty
void I2C_wait_for_idle(void);

// I2C_start() sends a start condition  
void I2C_start();

// I2C_stop() sends a stop condition  
void I2C_stop();

// I2C_restart() sends a repeated start/restart condition
void I2C_restart();

// I2C_ack() sends an ACK condition
void I2C_ack(void);

// I2C_nack() sends a NACK condition
void I2C_nack(void); // Acknowledge Data bit

// address is I2C slave address, set wait_ack to 1 to wait for ACK bit or anything else to skip ACK checking  
void I2C_write(unsigned char address, char wait_ack);

// value is the value of the data we want to send, set ack_nack to 0 to send an ACK or anything else to send a NACK  
void I2C_read(unsigned char *value, char ack_nack);

void I2C_init(double frequency);

// Write byte value to register at reg_address
void HDC2080_write(unsigned char reg_address, unsigned char value);

void BMP_write(uint8_t dev_id, uint8_t reg_address, uint8_t value, uint16_t len);

// Read a byte from register at reg_address and return in *value
void HDC2080_read(unsigned char reg_address, unsigned char *value);

void BMP_read(uint8_t dev_id, uint8_t reg_address, uint8_t *value, uint16_t len);

uint8_t BMP_meas_read(uint8_t dev_id, uint8_t reg_address, uint8_t *value, uint16_t len);

uint8_t BMP_config_read(uint8_t dev_id, uint8_t reg_address, uint8_t *value, uint16_t len);

void HDC_reset(void);

void HDC_rate(void);

void HDC_set_meas_mode(unsigned int mode);

void HDC_resolution(void);

void HDC_trigger(void);

int8_t get_sensor_data(struct bmp3_dev *dev);

uint8_t BMP_init(struct bmp3_dev *dev);

uint8_t BMP_trigger(struct bmp3_dev *dev);

double* conv_calib_data(uint8_t* reg_data, double* conv_cal_data);

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all MPLAB Harmony modules, including application(s). */
    SYS_Initialize ( NULL );
    
    DRV_HANDLE usart;
    
    int8_t rslt = BMP3_OK;
    uint16_t len = 1;
    uint8_t pwr_ctrl_status;
    uint8_t i;
    
    
    I2C_init(100000);
        
    //double result;

    dev.dev_id = BMP3_I2C_ADDR_PRIM;
    dev.intf = BMP3_I2C_INTF;
    dev.read = BMP_read;
    dev.write = BMP_write;
    dev.delay_ms = delay_ms;
    
    HDC_reset();
    delay_ms(250);
    HDC_set_meas_mode(1);
    HDC_rate();
    HDC_resolution();
    HDC_trigger();
    
    rslt = BMP_init(&dev);
    
    
    if(rslt == BMP3_OK)
    {
        BMP_trigger(&dev);
    }else{
        //Send an ERR code over USART
    }
    
    if (pwr_ctrl_status != 0x33)
    {
        BSP_LEDStateSet(U1_EN, BSP_LED_STATE_OFF);
        BSP_LEDStateSet(USER_LED2, BSP_LED_STATE_ON);
    }else{
        //Send an ERR code over USART
    }
    

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        delay_ms(1000);
        
        unsigned char temp[2];
        //unsigned char temp_high;
        unsigned char humid[2];
        //unsigned char humid_high;
        char input;
        
        uint32_t result;
        
//        uint8_t val1;
//        uint8_t val2;
//        uint8_t val3;
//        uint8_t val4;
//        uint8_t val5;
//        uint8_t val6;
        
        uint8_t reg_data[BMP3_P_T_DATA_LEN];
        
        struct bmp3_uncomp_data uncomp_data;
        uint8_t sensor_comp = BMP3_PRESS;
        
        usart = DRV_USART_Open(DRV_USART_INDEX_0, DRV_IO_INTENT_READWRITE | DRV_IO_INTENT_NONBLOCKING);
        
    
        while (true)
        {                                   //0x69
            uint8_t calib_data[21] = {0xD2, 0x69, 0x62, 0x49, 0xF6, 0x92, 0xFE, 
            0x1E, 0xF5, 0x23, 0x00, 0x7F, 0x65, 0xE7, 0x7B, 0xF3, 0xF6, 0x7B, 
            0x42, 0x0A, 0xC4};
            //{0x5A, 0x6B, 0xCB, 0x49, 0xF6, 0xAC, 0xFF, 0xB2,
            //0xF4, 0x23, 0x00, 0x4B, 0x63, 0x04, 0x79, 0xF3, 0xF6, 0x39, 0x3F, 0x13, 0xC4
            //};

            parse_calib_data(calib_data, &dev);
            
            BMP_meas_read(dev.dev_id, 0x04, &reg_data[0], len);
            //val1 = reg_data[0];

            BMP_meas_read(dev.dev_id, 0x05, &reg_data[1], len);
            //val2 = reg_data[1];

            BMP_meas_read(dev.dev_id, 0x06, &reg_data[2], len);
            //val3 = reg_data[2];
            
            BMP_meas_read(dev.dev_id, 0x07, &reg_data[3], len);
            //val4 = reg_data[3];

            BMP_meas_read(dev.dev_id, 0x08, &reg_data[4], len);
            //val5 = reg_data[4];

            BMP_meas_read(dev.dev_id, 0x09, &reg_data[5], len);
            //val6 = reg_data[5];
            
            parse_sensor_data(&reg_data, &uncomp_data);

            /* Compensate the pressure/temperature/both data read
            * from the sensor */
            result = compensate_data(sensor_comp, &uncomp_data, &data, &dev.calib_data);

            if (!DRV_USART_ReceiverBufferIsEmpty(usart)) {
                input = DRV_USART_ReadByte(usart);
                if (input == 'r')
                {
                    BSP_LEDStateSet(U1_EN, BSP_LED_STATE_ON);
                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    delay_ms(1000);
                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    HDC2080_read(TEMP_LOW, &temp[0]);
                    HDC2080_read(TEMP_HIGH, &temp[1]);
                    HDC2080_read(HUMID_LOW, &humid[0]);
                    HDC2080_read(HUMID_HIGH, &humid[1]);

                    BMP_meas_read(dev.dev_id, 0x04, &reg_data[0], len);
                    //val1 = reg_data[0];

                    BMP_meas_read(dev.dev_id, 0x05, &reg_data[1], len);
                    //val2 = reg_data[1];

                    BMP_meas_read(dev.dev_id, 0x06, &reg_data[2], len);
                    //val3 = reg_data[2];

                    BMP_meas_read(dev.dev_id, 0x07, &reg_data[3], len);
                    //val4 = reg_data[3];

                    BMP_meas_read(dev.dev_id, 0x08, &reg_data[4], len);
                    //val5 = reg_data[4];

                    BMP_meas_read(dev.dev_id, 0x09, &reg_data[5], len);
                    //val6 = reg_data[5];
                    
//                    parse_sensor_data(&reg_data, &uncomp_data);
//
//                    /* Compensate the pressure/temperature/both data read
//                    * from the sensor */
//                    result = compensate_data(sensor_comp, &uncomp_data, &data, &dev.calib_data);
//                    
//                    unsigned char *chptr;
//                    
//                    chptr = (unsigned char *) &data.pressure;
//                    DRV_USART_WriteByte(usart, *chptr++);
//                    delay_ms(500);
//                    DRV_USART_WriteByte(usart, *chptr++);
//                    delay_ms(500);
//                    DRV_USART_WriteByte(usart, *chptr++);
//                    delay_ms(500);
//                    DRV_USART_WriteByte(usart, *chptr);
//                    delay_ms(500);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, temp[0]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, temp[1]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, humid[0]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, humid[1]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, reg_data[0]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, reg_data[1]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, reg_data[2]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);
                    
                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, reg_data[3]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);
                    
                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, reg_data[4]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);
                    
                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
                    DRV_USART_WriteByte(usart, reg_data[5]);

                    delay_ms(250);

                    BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_OFF);

                    delay_ms(250);

                    DRV_USART_WriteByte(usart, 's'); 
                    BSP_LEDStateSet(U1_EN, BSP_LED_STATE_OFF);
                }
            }
        }
        delay_ms(1000);
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

void delay_us(unsigned int us)
{
    
    // Convert microseconds us into how many clock ticks it will take
    us *= SYS_FREQ / 1000000 / 2; // Core Timer updates every 2 ticks

    _CP0_SET_COUNT(0); // Set Core Timer count to 0

    while (us > _CP0_GET_COUNT()); // Wait until Core Timer count reaches the number we calculated earlier
}

void delay_ms(unsigned int ms)
{
    delay_us(ms * 1000);
}

void I2C_wait_for_idle(void)
{
    while(I2C2CON & 0x1F); // Acknowledge sequence not in progress
                                // Receive sequence not in progress
                                // Stop condition not in progress
                                // Repeated Start condition not in progress
                                // Start condition not in progress
    while(I2C2STATbits.TRSTAT); // Bit = 0 ? Master transmit is not in progress
}

// I2C_start() sends a start condition  
void I2C_start()
{
    I2C_wait_for_idle();
    I2C2CONbits.SEN = 1;
    while (I2C2CONbits.SEN == 1);
}

// I2C_stop() sends a stop condition  
void I2C_stop()
{
    I2C_wait_for_idle();
    I2C2CONbits.PEN = 1;
}

// I2C_restart() sends a repeated start/restart condition
void I2C_restart()
{
    I2C_wait_for_idle();
    I2C2CONbits.RSEN = 1;
    while (I2C2CONbits.RSEN == 1);
}

// I2C_ack() sends an ACK condition
void I2C_ack(void)
{
    I2C_wait_for_idle();
    I2C2CONbits.ACKDT = 0; // Set hardware to send ACK bit
    I2C2CONbits.ACKEN = 1; // Send ACK bit, will be automatically cleared by hardware when sent  
    while(I2C2CONbits.ACKEN); // Wait until ACKEN bit is cleared, meaning ACK bit has been sent
}

// I2C_nack() sends a NACK condition
void I2C_nack(void) // Acknowledge Data bit
{
    I2C_wait_for_idle();
    I2C2CONbits.ACKDT = 1; // Set hardware to send NACK bit
    I2C2CONbits.ACKEN = 1; // Send NACK bit, will be automatically cleared by hardware when sent  
    while(I2C2CONbits.ACKEN); // Wait until ACKEN bit is cleared, meaning NACK bit has been sent
}

// address is I2C slave address, set wait_ack to 1 to wait for ACK bit or anything else to skip ACK checking  
void I2C_write(unsigned char address, char wait_ack)
{
    I2C2TRN = address | 0;				// Send slave address with Read/Write bit cleared
    //while (I2C2STATbits.TBF == 1);		// Wait until transmit buffer is empty
    I2C_wait_for_idle();				// Wait until I2C bus is idle
    if (wait_ack) while (I2C2STATbits.ACKSTAT == 1); // Wait until ACK is received  
}

// value is the value of the data we want to send, set ack_nack to 0 to send an ACK or anything else to send a NACK  
void I2C_read(unsigned char *value, char ack_nack)
{
    I2C2CONbits.RCEN = 1;				// Receive enable
    while (I2C2CONbits.RCEN);			// Wait until RCEN is cleared (automatic)  
    while (!I2C2STATbits.RBF);    		// Wait until Receive Buffer is Full (RBF flag)  
    *value = I2C2RCV;    				// Retrieve value from I2C1RCV
    //return value;
    
    if (!ack_nack)						// Do we need to send an ACK or a NACK?  
        I2C_ack();						// Send ACK  
    else
        I2C_nack();						// Send NACK  
}

void I2C_init(double frequency)
{
    double BRG;
    
    I2C2CON = 0;			// Turn off I2C1 module
    I2C2CONbits.DISSLW = 1; // Disable slew rate for 100kHz
    
    BRG = (1 / (2 * frequency)) - 0.000000104;
    BRG *= (SYS_FREQ / 2) - 2;    
    
    I2C2BRG = (int)BRG;		// Set baud rate
    I2C2CONbits.ON = 1;		// Turn on I2C1 module
}

// Write byte value to register at reg_address
void HDC2080_write(unsigned char reg_address, unsigned char value)
{
    I2C_start();						/* Send start condition */  
    I2C_write(HDC_ADDRESS << 1, 1); /* Send HDC2080's address, read/write bit not set (AD + R) */  
    I2C_write(reg_address, 1);			/* Send the register address (RA) */  
    I2C_write(value, 1);				/* Send the value to set it to */  
    I2C_stop();    						/* Send stop condition */  
}

void BMP_write(uint8_t dev_id, uint8_t reg_address, uint8_t value, uint16_t len)
{
    I2C_start();						/* Send start condition */  
    I2C_write(dev_id << 1, 1); /* Send BMP's address, read/write bit not set (AD + R) */  
    I2C_write(reg_address, 1);			/* Send the register address (RA) */  
    I2C_write(value, 1);				/* Send the value to set it to */  
    I2C_stop();    						/* Send stop condition */  
}

// Read a byte from register at reg_address and return in *value
void HDC2080_read(unsigned char reg_address, unsigned char *value)
{
    I2C_start();						/* Send start condition */  
    I2C_write(HDC_ADDRESS << 1, 1);	/* Send HDC2080's address, read/write bit not set (AD + R) */  
    I2C_write(reg_address, 1);			/* Send the register address (RA) */  
    I2C_restart();						/* Send repeated start condition */  
    I2C_write(HDC_ADDRESS << 1 | 1, 1);	/* Send HDC2080's address, read/write bit set (AD + W) */  
    I2C_read(value, 1);					/* Read value from the I2C bus */  
    //return value;
    I2C_stop();    						/* Send stop condition */  
}

void BMP_read(uint8_t dev_id, uint8_t reg_address, uint8_t *value, uint16_t len)
{
    I2C_start();						/* Send start condition */  
    I2C_write(dev_id << 1, 1);	/* Send BMP's address, read/write bit not set (AD + R) */  
    I2C_write(reg_address, 1);			/* Send the register address (RA) */  
    I2C_restart();						/* Send repeated start condition */  
    I2C_write(dev_id << 1 | 1, 1);	/* Send BMP's address, read/write bit set (AD + W) */
    I2C_read(value, 1);
    //return value;
    I2C_stop();    						/* Send stop condition */  
}

uint8_t BMP_meas_read(uint8_t dev_id, uint8_t reg_address, uint8_t *value, uint16_t len)
{
    I2C_start();						/* Send start condition */  
    
    I2C_write(dev_id << 1, 1);	/* Send BMP's address, read/write bit not set (AD + R) */  
    I2C_write(reg_address, 1);			/* Send the register address (RA) */  
    I2C_restart();						/* Send repeated start condition */  
    I2C_write(dev_id << 1 | 1, 1);	/* Send BMP's address, read/write bit set (AD + W) */
    I2C_read(value, 1);   
    
    I2C_stop();    						/* Send stop condition */  
}

uint8_t BMP_config_read(uint8_t dev_id, uint8_t reg_address, uint8_t *value, uint16_t len)
{
    I2C_start();						/* Send start condition */  
    
    I2C_write(dev_id << 1, 1);	/* Send BMP's address, read/write bit not set (AD + R) */  
    I2C_write(reg_address, 1);			/* Send the register address (RA) */  
    I2C_restart();						/* Send repeated start condition */  
    I2C_write(dev_id << 1 | 1, 1);	/* Send BMP's address, read/write bit set (AD + W) */
    BSP_LEDStateSet(USER_LED2, BSP_LED_STATE_ON);
    I2C_read(value, 0);   
    BSP_LEDStateSet(USER_LED2, BSP_LED_STATE_OFF);
    
    I2C_stop();    						/* Send stop condition */  
}

void HDC_reset(void)
{
    unsigned char config_val;
    unsigned char reset;
    HDC2080_read(HDC_Config_Reg, &config_val);
    reset = config_val | 0x80;
    HDC2080_write(HDC_Config_Reg, reset);
}

void HDC_rate(void)
{
    unsigned char config_val;
    HDC2080_read(HDC_Config_Reg, &config_val);
    config_val = config_val & 0xDF;
    config_val = config_val | 0x50;
    HDC2080_write(HDC_Config_Reg, config_val);
}

void HDC_set_meas_mode(unsigned int mode)
{
    unsigned char config_val;
    HDC2080_read(HDC_Meas_Config_Reg, &config_val);
    
    switch(mode)
    {
        case 1: //Temp and Humidity
            config_val = config_val & 0xF9;
            break;
            
        case 2: //Temp Only
            config_val = config_val & 0xFC;
            config_val = config_val | 0x02;
            break;
            
        case 3: //Humidity only
            config_val = config_val & 0xFD;
            config_val = config_val | 0x04;
            break;
        default:
            config_val = config_val & 0xF9;
    }
    
    HDC2080_write(HDC_Meas_Config_Reg, config_val);
}

void HDC_resolution(void)
{
    unsigned char config_val;
    HDC2080_read(HDC_Meas_Config_Reg, &config_val);
    config_val = config_val & 0x3F;
    HDC2080_write(HDC_Meas_Config_Reg, config_val);
}

void HDC_trigger(void)
{
    unsigned char config_val;
    HDC2080_read(HDC_Meas_Config_Reg, &config_val);
    config_val = config_val | 0x01;
    HDC2080_write(HDC_Meas_Config_Reg, config_val);
}

int8_t get_sensor_data(struct bmp3_dev *dev)
{
    int8_t rslt;
    /* Variable used to select the sensor component */
    uint8_t sensor_comp;
    /* Variable used to store the compensated data */
    struct bmp3_data data;

    /* Sensor component selection */
    sensor_comp = BMP3_PRESS;
    /* Temperature and Pressure data are read and stored in the bmp3_data instance */
    rslt = bmp3_get_sensor_data(sensor_comp, &data, dev);

    return rslt;
}

uint8_t BMP_init(struct bmp3_dev *dev)
{
    uint8_t rslt = BMP3_OK;
    uint8_t chip_id = 0;
    uint16_t len = 1;
    uint8_t soft_rst_cmd = 0xB6;
    uint8_t cmd_rdy_status;
    uint8_t cmd_err_status;
    
    BMP_read(dev->dev_id, BMP3_CHIP_ID_ADDR, &chip_id, len);
    dev->chip_id = chip_id;
    BMP_read(dev->dev_id, BMP3_SENS_STATUS_REG_ADDR, &cmd_rdy_status, len);
    if ((cmd_rdy_status & BMP3_CMD_RDY) && (rslt == BMP3_OK))
    {
            /* Write the soft reset command in the sensor */
        BMP_write(dev->dev_id, BMP3_CMD_ADDR, soft_rst_cmd, 1);
    }
    BMP_read(dev->dev_id, BMP3_ERR_REG_ADDR, &cmd_err_status, 1);
    if ((cmd_err_status & BMP3_CMD_ERR) || (rslt != BMP3_OK))
    {
        /* Command not written hence return
        * error */
        rslt = BMP3_E_CMD_EXEC_FAILED;
    }
    
    if (rslt == BMP3_E_CMD_EXEC_FAILED)
    {
        BSP_LEDStateSet(USER_LED1, BSP_LED_STATE_ON);
    }
    
    return rslt;
}

uint8_t BMP_trigger(struct bmp3_dev *dev)
{
    uint16_t len = 1;
    uint8_t pwr_ctrl_status;
    
    BMP_read(dev->dev_id, BMP3_PWR_CTRL_ADDR, &pwr_ctrl_status, len);
    pwr_ctrl_status = 0x00;
    BMP_write(dev->dev_id, BMP3_PWR_CTRL_ADDR, 0x01, len);
    BMP_read(dev->dev_id, BMP3_PWR_CTRL_ADDR, &pwr_ctrl_status, len);
    if(pwr_ctrl_status == 0x01)
    {
        BMP_write(dev->dev_id, BMP3_PWR_CTRL_ADDR, 0x33, len);
        pwr_ctrl_status = 0x00;
    }
    BMP_read(dev->dev_id, BMP3_PWR_CTRL_ADDR, &pwr_ctrl_status, len);
    
    return pwr_ctrl_status;
}

double* conv_calib_data(uint8_t* reg_data, double* conv_cal_data)
{
    double temp_var;
    uint16_t temp_combo[14];

    /* 1 / 2^8 */
    temp_var = 0.00390625f;
    temp_combo[0] = BMP3_CONCAT_BYTES(reg_data[1], reg_data[0]);
    conv_cal_data[0] = ((double)temp_combo[0] / temp_var);
    temp_combo[1] = BMP3_CONCAT_BYTES(reg_data[3], reg_data[2]);
    temp_var = 1073741824.0f;
    conv_cal_data[1] = ((double)temp_combo[1] / temp_var);
    temp_combo[2] = (int8_t)reg_data[4];
    temp_var = 281474976710656.0f;
    conv_cal_data[2] = ((double)temp_combo[2] / temp_var);
    temp_combo[3] = (int16_t)BMP3_CONCAT_BYTES(reg_data[6], reg_data[5]);
    temp_var = 1048576.0f;
    conv_cal_data[3] = ((double)(temp_combo[3] - (16384)) / temp_var);
    temp_combo[4] = (int16_t)BMP3_CONCAT_BYTES(reg_data[8], reg_data[7]);
    temp_var = 536870912.0f;
    conv_cal_data[4] = ((double)(temp_combo[4] - (16384)) / temp_var);
    temp_combo[5] = (int8_t)reg_data[9];
    temp_var = 4294967296.0f;
    conv_cal_data[5] = ((double)temp_combo[5] / temp_var);
    temp_combo[6] = (int8_t)reg_data[10];
    temp_var = 137438953472.0f;
    conv_cal_data[6] = ((double)temp_combo[6] / temp_var);
    temp_combo[7] = BMP3_CONCAT_BYTES(reg_data[12], reg_data[11]);

    /* 1 / 2^3 */
    temp_var = 0.125f;
    conv_cal_data[7] = ((double)temp_combo[7] / temp_var);
    temp_combo[8] = BMP3_CONCAT_BYTES(reg_data[14], reg_data[13]);
    temp_var = 64.0f;
    conv_cal_data[8] = ((double)temp_combo[8] / temp_var);
    temp_combo[9] = (int8_t)reg_data[15];
    temp_var = 256.0f;
    conv_cal_data[9] = ((double)temp_combo[9] / temp_var);
    temp_combo[10] = (int8_t)reg_data[16];
    temp_var = 32768.0f;
    conv_cal_data[10] = ((double)temp_combo[10] / temp_var);
    temp_combo[11] = (int16_t)BMP3_CONCAT_BYTES(reg_data[18], reg_data[17]);
    temp_var = 281474976710656.0f;
    conv_cal_data[11] = ((double)temp_combo[11] / temp_var);
    temp_combo[12] = (int8_t)reg_data[19];
    temp_var = 281474976710656.0f;
    conv_cal_data[12] = ((double)temp_combo[12] / temp_var);
    temp_combo[13] = (int8_t)reg_data[20];
    temp_var = 36893488147419103232.0f;
    conv_cal_data[13] = ((double)temp_combo[13] / temp_var);
    
    return conv_cal_data;
}